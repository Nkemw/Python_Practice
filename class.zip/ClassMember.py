class MyClass :
    var = "안녕하세요!!"

    def sayHello(self):
        msg1 = "안녕"
        self.msg2 = "Hi"
        print(msg1)
        print(self.var)


obj = MyClass()
print(obj.var)          #객체를 통한 클래스 멤버 접근이 가능
obj.sayHello()          #객체의 메소드를 통해 접근
print(MyClass.var)      #클래스 이름으로 접근