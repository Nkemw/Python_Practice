class Human :
    def __init__(self, age, name) :
        self.age = age
        self.name = name
    def __eq__(self, other) :
        return self.name == other.name

kim = Human(29, "홍길동")
sang = Human(30, "홍길동")
moon = Human(30, "이순신")
print(kim == sang)
print(kim == moon)