class FileName:
    def __init__(self, name, time):
        self.name = name
        self.time = time
    def print_filename(self):
        print("파일 이름: {0}, 파일 생성된 시각: {1}".format(self.name, self.time))

class PDF(FileName):
    def date(self, date):
        self.date = date
    def print_filename(self):
        print("PDF 파일 이름: {0}, 파일 생성된 시각: {1} {2}".format(self.name, self.date, self.time))

first_file = FileName("1차 보고서", "2시 30분")
first_file.print_filename()
second_file = PDF("2차 보고서", "3시 30분")
second_file.date("2021년 10월 20일")
second_file.print_filename()