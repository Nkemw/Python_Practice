class Calculator:
    @staticmethod
    def plus (a, b):
        return a+b
    
    @staticmethod
    def minus (a, b):
        return a-b

result = Calculator.plus(3, 5)
print(result)
cal1 = Calculator()
print(cal1.minus(5, 3))