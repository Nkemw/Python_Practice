class Info:
    def __init__(self, age, major, name):
        self.age = age
        self.major = major
        self.name = name

    def __call__(self):
        print("{0}살 {1} {2}".format(self.age, self.major, self.name))

person = Info(23, "컴퓨터공학과", "김민우")
person()