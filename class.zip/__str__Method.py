class RealNumber:
    def __init__(self, num1, num2):
        self.result = num1/num2

    def __str__(self):
        return "결과: %f"%(self.result)

number = RealNumber(5, 3)
print(number)