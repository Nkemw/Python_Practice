class Add :
    def add(self, a, b) :
        return a+b

class Multiply :
    def multiply(self, a, b) :
        return a*b
        
class Calculator(Add, Multiply) :
    def sub(self, a, b) :
        return a-b

c = Calculator()
print(c.add(1,2))
print(c.multiply(2,10))