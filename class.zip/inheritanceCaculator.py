class Add :
    def add(self, a, b) :
        return a+b
class Minus :
    def minus(self, a, b):
        return a-b

class Multiply :
    def multiply(self, a, b) :
        return a*b

class Divide :
    def divide(self, a, b) :
        return a/b

class Calculator(Add, Minus, Multiply, Divide) :
    pass

c = Calculator()
print(c.add(4,2))
print(c.minus(4,2))
print(c.multiply(4,2))
print(c.divide(4,2))